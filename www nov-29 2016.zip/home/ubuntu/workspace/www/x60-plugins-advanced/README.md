I grouped all these folders into this folder so that it was not so overwhelming. Make sure you drag each of these folders into the www folder to make them active.



************************************************************************************************************

###Disclaimer: I spend my time getting complex things working in simple ways. I have no idea if I am doing anything correctly so please beware if you use my work. If you like this App and can hum, play or sing please help the musically illiterate, use a flash capable computer to add your favorite song at http://www.rocksetta.com                              twitter @rocksetta 













