j23-sound-pgb-helloworld
========================



April 15, 2014. NOT VERY HAPPY. Using Phonegap Build on an Android phone I Can not get polyphonic sound like I can using the Chrome browser. I can get non-polyphonic mp3 sound, from both the sdcard and the internet using HTML5 audio tags and javascript.


Can not load anything from the local android_asset/www folder. Also can not record audio. 


Using Phonegap Client I can do most of the audio things I wish to do. That code is not posted here.

I have lots of old files on this repository but the only useful file is index.html. To get the sdcard sounds working you need sound files on the sdcard.











