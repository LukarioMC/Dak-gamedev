Refer to http://spark.io for how to purchase a $19 spark photon.

This folder shows how to control an arduino style internet capable device using just a web page.

The advanced html file shows slightly better use using AJAX and JSON with a polling example to read a sensor every 5 seconds and a slider to control the brightness of an LED


