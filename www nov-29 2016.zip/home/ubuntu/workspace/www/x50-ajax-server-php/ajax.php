<?php

  echo "Here is a php server generated random number = ".rand(1,99)."<br>";
   
?>
