
If your Nitrous.io project has been saved to github you can have phonegap build compile it into a full app that you can install on you mobile device. Much easier to install on Android than win8 or apple.

 


